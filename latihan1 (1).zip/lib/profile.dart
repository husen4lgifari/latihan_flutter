import 'package:flutter/material.dart';

class Profile extends StatelessWidget {
  const Profile({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("MyProfil"),
      ),
      body: Column(
        children: [
          Center(
            child: CircleAvatar(
              radius: 80, // Ukuran gambar
              backgroundImage: NetworkImage(
                "https://tse2.mm.bing.net/th?id=OIP.47uXWxkt8TwcIf2_OjuplQHaHa&pid=Api&P=0&h=180",
              ),
            ),
          ),
          SizedBox(height: 20), // Spasi antara gambar dan informasi
          ListTile(
            leading: Icon(Icons.person),
            title: Text("Nama"),
            subtitle: Text("Husen Algifari"),
          ),
          ListTile(
            leading: Icon(Icons.phone),
            title: Text("No.Telepon"),
            subtitle: Text("083129055606"),
          ),
          ListTile(
            leading: Icon(Icons.email),
            title: Text("Email"),
            subtitle: Text("husenalgifari38@gmail.com"),
          )
        ],
      ),
    );
  }
}
